#include<stdio.h>
#include<stdlib.h>
#include<libvirt/libvirt.h>
#include<math.h>
#include<string.h>
#include<unistd.h>
#include<limits.h>
#include<signal.h>
#define MIN(a,b) ((a)<(b)?a:b)
#define MAX(a,b) ((a)>(b)?a:b)

long long int* prevMemUse = NULL;
long long int firstVcupu = 0;

int is_exit = 0; // DO NOT MODIFY THE VARIABLE

void MemoryScheduler(virConnectPtr conn,int interval);

/*
DO NOT CHANGE THE FOLLOWING FUNCTION
*/
void signal_callback_handler()
{
	printf("Caught Signal");
	is_exit = 1;
}

/*
DO NOT CHANGE THE FOLLOWING FUNCTION
*/
int main(int argc, char *argv[])
{
	virConnectPtr conn;

	if(argc != 2)
	{
		printf("Incorrect number of arguments\n");
		return 0;
	}

	// Gets the interval passes as a command line argument and sets it as the STATS_PERIOD for collection of balloon memory statistics of the domains
	int interval = atoi(argv[1]);
	
	conn = virConnectOpen("qemu:///system");
	if(conn == NULL)
	{
		fprintf(stderr, "Failed to open connection\n");
		return 1;
	}

	signal(SIGINT, signal_callback_handler);

	while(!is_exit)
	{
		// Calls the MemoryScheduler function after every 'interval' seconds
		MemoryScheduler(conn, interval);
		sleep(interval);
	}

	// Close the connection
	virConnectClose(conn);
	free( prevMemUse );
	return 0;
}

/*
COMPLETE THE IMPLEMENTATION
*/
void MemoryScheduler(virConnectPtr conn, int interval)
{
	printf("\n=========================================\n");
	printf("interval : %d\t", interval);

	virDomainPtr *domains;
	virDomainInfoPtr info = malloc(sizeof(virDomainInfo));
	virDomainMemoryStatPtr memInfo= malloc(14*sizeof(virDomainMemoryStatStruct));

	int numDomains = virConnectListAllDomains(conn, &domains, VIR_CONNECT_LIST_DOMAINS_RUNNING);
	printf("Num of domains : %d\n", numDomains);

	if( prevMemUse == NULL )
		prevMemUse = calloc( numDomains, sizeof( long long int ) );

	long long int* ballonSize = calloc( numDomains, sizeof( long long int ) );
	long long int* unUsed = calloc( numDomains, sizeof( long long int ) );
	long long int* memRequired = calloc( numDomains, sizeof( long long int ) );
	long long int* canRelease = calloc( numDomains, sizeof( long long int ) );
	int allVmMaxed = 1;

	for( size_t i = 0; i < numDomains; i++)
	{
		virDomainSetMemoryStatsPeriod( domains[i], interval, VIR_DOMAIN_AFFECT_LIVE );
		virDomainGetInfo( domains[i], info );
		virDomainMemoryStats( domains[i], memInfo, 14, 0 );

		long long int total, free, used;
		for(size_t j = 0;j < 14; j++)
		{
			if( memInfo[j].tag == VIR_DOMAIN_MEMORY_STAT_ACTUAL_BALLOON )
			{
				total = memInfo[j].val/1024;				
				printf(" Baloon : %lld \t", total);
			}
			if( memInfo[j].tag == VIR_DOMAIN_MEMORY_STAT_UNUSED )
			{
				free = memInfo[j].val/1024;				
				printf(" Unused : %lld \t", free);
			}		
		}
		ballonSize[i] = total;
		unUsed[i] = free;
		used = total - free;
		printf(" memory used : %lld\n", used);

		if( prevMemUse[i] != 0)
		{
			if( used > prevMemUse[i] + 5 )
			{
				memRequired[i] = MIN( MAX(used - prevMemUse[i], 50), info->maxMem/1024 - total );
			}
			else if ( used <= prevMemUse[i] && free > 100)
			{
				canRelease[i] = MIN( 50, free - 100 );
				allVmMaxed = 0;
			}
		}
		prevMemUse[i] = used;
	}

	size_t freeMemPtr = 0;

	for( size_t i = 0; i < numDomains; i++)
	{
		long long int vCupu = ( i + firstVcupu ) % numDomains;
		if( memRequired[ vCupu ] != 0 )
		{
			if( allVmMaxed == 0  )
			{
				for( ; freeMemPtr < numDomains; freeMemPtr++ )
				{
					if( memRequired[vCupu] != 0 && canRelease[freeMemPtr] != 0 )
					{
						long long int memTransfered = MIN( canRelease[freeMemPtr], memRequired[vCupu] );
						printf("Transfered %lld from %ld to %lld \n", memTransfered, freeMemPtr, vCupu);
						virDomainSetMemory( domains[freeMemPtr], (ballonSize[freeMemPtr] - memTransfered)*1024 );
						virDomainSetMemory( domains[vCupu], (ballonSize[vCupu] + memTransfered)*1024 );
						memRequired[vCupu] -= memTransfered;
						canRelease[freeMemPtr] -= memTransfered;
					}
					if(memRequired[vCupu] == 0)
						break;
				}
			}
			else
			{
				long long int freeMem = virNodeGetFreeMemory( conn )/1024;
				if( freeMem > 200 )
				{
					long long int memTransfered = MIN( 50, MIN( memRequired[vCupu], freeMem - 200 ) );
					virDomainSetMemory( domains[vCupu], (ballonSize[vCupu] + memTransfered)*1024 );
					printf( "Transfering %lld from host to %ld: hast has %lld left \n", memTransfered, i, freeMem - memTransfered );
					memRequired[vCupu] -= memTransfered;
				}
			}
			
			
		}
	}
	firstVcupu++;

	free(info);
	free(memInfo);
	free(ballonSize);
	free(unUsed);
	free(memRequired);
	free(canRelease);

}
